package com.example.GPSprototype;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;

public class SQLHelper extends SQLiteOpenHelper{

    public static final String DATABASE_NAME = "Geo.db";
    public static final String TABLE_NAME = "GeoPoints_Table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "Lat";
    public static final String COL_3 = "Long";
    public static final String COL_4 = "KillTime";



    public SQLHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,LAT DECIMAL, LONG DECIMAL/*, KILLTIME DATE*/)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    db.execSQL("drop table if exists " + TABLE_NAME);
    onCreate(db);
    }
                                //make these into bools for the LAT and LONG to pass through
    public boolean insertData( String Lat, String Long/*, String KillTime*/){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        //values going into the columns

        contentValues.put(COL_2, Lat);
        contentValues.put(COL_3, Long);
        //contentValues.put(COL_4, KillTime);


        long result = db.insert(TABLE_NAME, null, contentValues);

        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
    Cursor res = db.rawQuery("Select * from " + TABLE_NAME, null);
    return res;

    }
}
