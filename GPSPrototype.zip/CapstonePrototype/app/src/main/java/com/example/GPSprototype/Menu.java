package com.example.GPSprototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {

    //Variables
    private Button StartTracking;
    private Button SuperSecretDatabase;
    private Button LeaveApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        StartTracking = (Button) findViewById(R.id.MenuTrack);
        StartTracking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTrackingMenu();
            }
        });

        SuperSecretDatabase = (Button) findViewById(R.id.SuperSecretDatabase);
        SuperSecretDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSuperSecret();
            }
        });


        LeaveApp = (Button) findViewById(R.id.MenuExit);
        LeaveApp.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
                LeaveApp();
            }
        });

    }
    public void openTrackingMenu(){
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }
    public void openSuperSecret(){
        Intent intent = new Intent(this, SuperSecretDatabase.class);
        startActivity(intent);
    }
    public void LeaveApp(){
        System.exit(0);
    }
}
