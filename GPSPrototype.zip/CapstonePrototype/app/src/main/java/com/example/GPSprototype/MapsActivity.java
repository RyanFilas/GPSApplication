package com.example.GPSprototype;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;


    private LocationListener locationListener;
    private LocationManager locationManager;

    //Calling DB
    private SuperSecretDatabase superSecretDatabase;
    public MapsActivity(SuperSecretDatabase superSecretDatabase){
        this.superSecretDatabase = superSecretDatabase;
    }
    //calling helper
    private SQLHelper sqlHelper;
    public MapsActivity(SQLHelper sqlHelper){
        this.sqlHelper = sqlHelper;
    }



    //This is 1 second * however many seconds I want the min time to be.
    private final long MIN_TIME = 1000 * 7;
    //This is Minimal distance traveled #
    private final long MIN_DIST = 2;

    private LatLng latLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        //Checks to see if the permissions are granted
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PackageManager.PERMISSION_GRANTED);

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //Circle circle = mMap.addCircle(new CircleOptions().center(latLng).radius(500).strokeColor(Color.CYAN));
        //This doesn't load a map style for some reason unsure as to why
        //mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        // Starts marker and camera at given position (My Dorm)
        //LatLng room = new LatLng(41.944193, -78.670483);
        //mMap.addMarker(new MarkerOptions().position(room).title("Start Location"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(room));
        //mMap.setMinZoomPreference(10);


        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {



                try {
                    //puts pulled location into a variable
                    latLng = new LatLng(location.getLatitude(), location.getLongitude());
                    //updates the location with a red marker to show current location
                    mMap.addMarker(new MarkerOptions().position(latLng).title("Current Position"));

                    //updates camera location to location based on this variable
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    //changes zoom to match location
                    mMap.setMinZoomPreference(17);


                    //New testing

                    ContentValues contentValues = new ContentValues();
                    //setting content values

                    contentValues.put(SQLHelper.COL_2, latLng.latitude);
                    contentValues.put(SQLHelper.COL_3, latLng.longitude);


                    //insert task
                   // sqlHelper.insertData(latLng.latitude,latLng.longitude);

                    //pops up after completion
                    //Toast.makeText(getBaseContext(), "Marker is added to the Map", Toast.LENGTH_SHORT);


                } catch (SecurityException e) {
                    e.printStackTrace();
                }

            }


            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }

        };

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DIST, locationListener);
        } catch (SecurityException e) {
            e.printStackTrace();
        }


    }
}


