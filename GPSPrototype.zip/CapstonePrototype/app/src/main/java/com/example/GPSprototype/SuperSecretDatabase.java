package com.example.GPSprototype;

import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;

import static android.widget.Toast.LENGTH_LONG;




public class SuperSecretDatabase extends AppCompatActivity {

    //Database stuff
    SQLHelper myDb;
    EditText editLat,editLong,editKillTime;
    Button AddDataButton;
    Button ViewDataButton;

    private MapsActivity mapsActivity;
    public SuperSecretDatabase(MapsActivity mapsActivity){
        this.mapsActivity = mapsActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //DATABASE WIP
        myDb = new SQLHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_super_secret_database);

        editLat = (EditText)findViewById(R.id.LatTextView);
        editLong = (EditText)findViewById(R.id.LongTextView);
        editKillTime = (EditText)findViewById(R.id.KillTimeTextView);
        AddDataButton = (Button)findViewById(R.id.AddDataButton);
        ViewDataButton = (Button)findViewById(R.id.ViewDataButton);

        AddData();
        viewAll();
    }


    public void AddData(){
        AddDataButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(editLat.toString(),editLong.toString());
                        if (isInserted = true)
                            Toast.makeText(SuperSecretDatabase.this, "Data Inserted", LENGTH_LONG).show();
                        else
                            Toast.makeText(SuperSecretDatabase.this, "Data Not Inserted", LENGTH_LONG).show();
                    }
                }
        );
    }

/*


public void AddData(){
    AddDataButton.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
    double IncomingLAT = MapsActivity.;
    double IncomingLNG = 0;


    boolean isInserted = (boolean) myDb.insertData(IncomingLAT, IncomingLNG);
        if (isInserted = true)
            Toast.makeText(SuperSecretDatabase.this, "Data Inserted", LENGTH_LONG).show();
        else
            Toast.makeText(SuperSecretDatabase.this, "Data Not Inserted", LENGTH_LONG).show();*/

    public void viewAll(){
        ViewDataButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        Cursor res = myDb.getAllData();
                            if ((res.getCount() == 0)){
                                showMessage("Error", "Nothing Found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("ID: "+ res.getString(0)+"\n");
                            buffer.append("Lat: "+ res.getString(1)+"\n");
                            buffer.append("Long: "+ res.getString(2)+"\n");
                            buffer.append("KillTime: "+ res.getString(3)+"\n\n");
                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

}
